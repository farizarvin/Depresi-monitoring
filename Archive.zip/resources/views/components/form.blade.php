@props([
    ''
])

<div class="overlay w-100 h-100 fixed top-0">
    <div class="row">
        <div class="col-6">
            <div class="card">
                <form action="" method="post">
                    @csrf
                    
                </form>
            </div>
        </div>
    </div>
</div>