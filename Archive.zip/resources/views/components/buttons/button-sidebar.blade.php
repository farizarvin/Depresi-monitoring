<a href="{{ $href }}" class="nav-link {{ $active ? 'active' : '' }}">
    <i class="bi {{ $icon }} nav-icon"></i>
    <span class="nav-text">{{ $text }}</span>
</a>
