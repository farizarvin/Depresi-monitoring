@extends('errors.minimal')

@section('title', 'Kesalahan Server')
@section('code', '500')
@section('message', 'Terjadi Kesalahan pada Server')
@section('description', 'Maaf, terjadi kesalahan internal pada server kami. Silakan coba beberapa saat lagi.')
