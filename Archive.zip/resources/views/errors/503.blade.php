@extends('errors.minimal')

@section('title', 'Sedang Maintenance')
@section('code', '503')
@section('message', 'Sedang Dalam Pemeliharaan')
@section('description', 'Maaf, layanan kami sedang dalam pembaikan. Kami akan segera kembali.')
