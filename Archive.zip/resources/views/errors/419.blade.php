@extends('errors.minimal')

@section('title', 'Halaman Kadaluarsa')
@section('code', '419')
@section('message', 'Halaman Kadaluarsa')
@section('description', 'Maaf, sesi halaman Anda telah berakhir. Silakan muat ulang halaman.')
@section('button', 'Muat Ulang Halaman')
