<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Admin Dashboard'); ?></title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <!-- Font Awesome (for legacy admin components) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- Layout CSS (Reusing Siswa Layout for consistency) -->
    <link rel="stylesheet" href="<?php echo e(asset('css/siswa/layout.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('vendor/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>">
    
    
    
    <!-- Page Specific CSS -->
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Admin Sidebar Component -->
    <?php echo $__env->make('components.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header Component -->
        <?php echo $__env->make('components.header', [
            'title' => $pageTitle ?? 'Admin Dashboard',
            'subtitle' => $pageSubtitle ?? 'Panel Administrasi'
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Content -->
        <div class="content-container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- jQuery (Needed for some admin components like modal events in table.blade.php) -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Layout JS -->
    <script src="<?php echo e(asset('js/siswa/layout.js')); ?>"></script>
    
    <script src="<?php echo e(asset('js/alpine.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.0/Chart.bundle.min.js"></script>
    
    <!-- Page Specific JS -->
    <?php echo $__env->yieldContent('scripts'); ?>
    <script>
        window.addEventListener('swal:alert', event => {

            const icon=event.detail.icon || 'info';
            let textColor='text-white';
            let bgColor;
            switch(icon)
            {
                case 'error' :
                    bgColor='bg-danger';
                    break;
                case 'success' :
                    bgColor='bg-success';
                    break;
                case 'warning' :
                    bgColor='bg-warning';
                    textColor='text-dark';
                    break;
                default : 
                    bgColor='bg-info';
                    break;
            }
            Swal.fire({
                icon: event.detail.icon || 'info',
                title: event.detail.title || 'Info',
                text: event.detail.text || '',
                iconColor : textColor==='text-dark' ? 'black' : 'white',
                toast: true,
                showConfirmButton : false,
                timerProgressBar: true,
                timer: 3000,
                position: "top",
                customClass : {
                    popup : `${bgColor} ${textColor}`,
                    title : `${textColor} ml-2 mt-2`,
                    htmlContainer : `${textColor} ml-2`,
                    
                },
                didOpen: ()=> {
                    
                }
            });
        });

        window.addEventListener('swal:confirm', event => {
            Swal.fire({
                title: event.detail.title || 'Konfirmasi',
                text: event.detail.text || '',
                icon: event.detail.icon || 'warning',
                
                
                showCancelButton: true,
                confirmButtonText: event.detail.confirmButtonText || 'Ya',
                cancelButtonText: event.detail.cancelButtonText || 'Batal',
                
            }).then((result) => {
                if(result.isConfirmed) event.detail.method()
            });
        });
    </script>
    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session()->has('success')): ?>
        
        <script>

            setTimeout(()=>{window.dispatchEvent(new CustomEvent('swal:alert', {detail : <?php echo json_encode(session('success'), 15, 512) ?>}))}, 400)
        </script>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(session()->has('alert')): ?>
        <script>

            alert("<?php echo e(session('alert')['text']); ?>")
        </script>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(session()->has('error')): ?>
    
        <script>

            setTimeout(()=>{window.dispatchEvent(new CustomEvent('swal:alert', {detail : <?php echo json_encode(session('error'), 15, 512) ?>}))}, 400)
        </script>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</body>
</html>
<?php /**PATH /Users/arvin/riset/laravel/resources/views/layouts/admin.blade.php ENDPATH**/ ?>