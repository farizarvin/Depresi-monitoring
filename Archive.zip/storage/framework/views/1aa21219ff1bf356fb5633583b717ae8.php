<?php $__env->startSection('title', 'Halaman Tidak Ditemukan'); ?>
<?php $__env->startSection('code', '404'); ?>
<?php $__env->startSection('message', 'Halaman Tidak Ditemukan'); ?>
<?php $__env->startSection('description', 'Maaf, halaman yang Anda cari tidak dapat ditemukan atau telah dipindahkan.'); ?>

<?php echo $__env->make('errors.minimal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arvin/riset/laravel/resources/views/errors/404.blade.php ENDPATH**/ ?>