<div class="mb-3">
    <label for="perasaan" class="form-label">Bagaimana perasaan hari ini? <span class="text-danger">*</span></label>
    <textarea 
        id="perasaan" 
        name="perasaan" 
        class="form-textarea" 
        placeholder="Contoh: Senang, sedih, semangat, lelah, dll..."
        rows="3"
    ></textarea>
</div>

<div class="mb-4">
    <label for="catatan" class="form-label">Ceritakan perasaan hari ini <span class="text-danger">*</span></label>
    <textarea 
        id="catatan" 
        name="catatan" 
        class="form-textarea" 
        placeholder="Tulis cerita atau pengalaman hari ini..."
        rows="3"
    ></textarea>
    
    <input type="hidden" name="emoji" value="3">
</div>
<?php /**PATH /Users/arvin/riset/laravel/resources/views/components/presensi/mood-form.blade.php ENDPATH**/ ?>