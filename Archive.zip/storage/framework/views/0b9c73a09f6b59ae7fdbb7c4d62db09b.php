<?php $__env->startSection('title', 'Index Siswa'); ?>
<?php $__env->startSection('content_header'); ?>
    <div class="row justify-content-center">
        <div class="col-11">
            <h1 class="m-0">Siswa</h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row g-4" x-data="{selected_id : `<?php echo e(old('id')); ?>`, id_user : `<?php echo e(old('id_user')); ?>`}" x-ref="mainContainer">
    <div class="col-12 col-lg-8">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-success bg-gradient bg-opacity-50 no-after p-4">
                <h6 class="m-0 fw-medium fs-5 text-black-50 mb-3">Daftar Siswa</h6>
                <form method="GET" class="row g-2 align-items-center">
                    <div class="col-12 col-md-4">
                        <input type="text" name="search" class="form-control" placeholder="Cari nama atau NISN..." value="<?php echo e($search ?? ''); ?>">
                    </div>
                    <div class="col-4 col-md-2">
                        <select name="class" class="form-select">
                            <option value="">Semua Kelas</option>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($class->id); ?>" <?php echo e($classFilter == $class->id ? 'selected' : ''); ?>>
                                    <?php echo e($class->nama); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                    </div>
                    <div class="col-4 col-md-2">
                        <select name="status" class="form-select">
                            <option value="">Semua Status</option>
                            <option value="1" <?php echo e($statusFilter === '1' ? 'selected' : ''); ?>>Aktif</option>
                            <option value="0" <?php echo e($statusFilter === '0' ? 'selected' : ''); ?>>Non-Aktif</option>
                        </select>
                    </div>
                    <div class="col-4 col-md-2">
                        <select name="gender" class="form-select">
                            <option value="">Semua Gender</option>
                            <option value="1" <?php echo e($genderFilter === '1' ? 'selected' : ''); ?>>Laki-laki</option>
                            <option value="0" <?php echo e($genderFilter === '0' ? 'selected' : ''); ?>>Perempuan</option>
                        </select>
                    </div>
                    <div class="col-12 col-md-2">
                        <button type="submit" class="btn btn-warning w-100">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
            </div>
            <div class="card-body p-4">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover shadow-none">
                        <thead class="text-black-50">
                            <tr>
                                <th scope="col" class="text-center py-3 fw-medium">No</th>
                                <th scope="col" class="py-3 fw-medium">Siswa</th>
                                <th scope="col" class="py-3 fw-medium">Gender</th>
                                <th scope="col" class="py-3 fw-medium">Kelas</th>
                                <th scope="col" class="py-3 fw-medium">Status</th>
                                <th scope="col" class="py-3 fw-medium" style="width: 120px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr :class="{'table-active' : selected_id==`<?php echo e($row->id); ?>`}">
                                    <td class="text-center text-dark">
                                        <?php echo e($i + 1); ?>

                                    </td>
                                    
                                    <td>
                                        <small>
                                            <div class="fw-medium"><?php echo e($row->nama_lengkap); ?></div>
                                            <div class="text-black-50"><?php echo e($row->nisn); ?></div>
                                        </small>
                                        
                                    </td>
                                    <td><?php echo e($row->gender ? "L" : "P"); ?></td>
                                    <td><?php echo e($row->getKelasAktif()?->nama); ?></td>
                                    <td>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$row->status): ?>
                                            <div class="badge badge-sm bg-danger bg-opacity-50 rounded-pill">Non-Aktif</div>
                                        <?php else: ?>
                                            <div class="badge badge-sm bg-success bg-opacity-75 rounded-pill">Aktif</div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                    <td >
                                        <a 
                                        href="#" 
                                        role="button"
                                        class="btn btn-sm btn-warning"
                                        x-on:click="event.preventDefault();selected_id=`<?php echo e($row->id); ?>`"
                                        onclick="editForm(`<?php echo e($row->id); ?>`, `<?php echo e(route('admin.siswa.update', ['siswa'=>$row->id])); ?>`, `<?php echo e($row->user->id); ?>`)"
                                        >
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a 
                                        href="#" 
                                        role="button"
                                        class="btn btn-sm btn-danger"
                                        x-on:click="event.preventDefault();setDeleteForm(`<?php echo e(route('admin.siswa.destroy', ['siswa'=>$row->id])); ?>`)"
                                        onclick="window.dispatchEvent(new CustomEvent('swal:confirm', {detail : {
                                            title : 'Konfirmasi hapus data',
                                            text : 'Apakah anda yakin ingin menghapus siswa ini?',
                                            icon : 'warning',
                                            method : submitDeleteForm,
                                        }}))"
                                        >
                                            <i class="fas fa-trash-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="bg-light-subtle text-center text-black-50 py-4">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($search || $classFilter || $statusFilter !== null || $genderFilter !== null): ?>
                                            <i class="fas fa-search fa-2x mb-2 text-muted"></i>
                                            <div>Tidak ditemukan data siswa yang sesuai</div>
                                            <small class="text-muted">Coba ubah kata kunci pencarian atau filter</small>
                                        <?php else: ?>
                                            <i class="fas fa-inbox fa-2x mb-2 text-muted"></i>
                                            <div>Belum ada data siswa</div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                </tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer py-4 px-4">
                <div class="d-flex justify-content-left">
                    <?php echo e($students->links()); ?>

                </div>
            </div>
        </div>

        <form 
            method="post" 
            id="form-delete" 
            class="d-none"
        >
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>
    </div>
    
    <div class="col-12 col-lg-4">
        <form 
            <?php if(old('id')==null): ?>
            action="<?php echo e(route('admin.siswa.store')); ?>"
            <?php else: ?>
            action="<?php echo e(route('admin.siswa.update', ['siswa'=>old('id')])); ?>"
            <?php endif; ?>
            method="POST" 
            id="form-siswa"
            class="d-flex flex-column gap-4" 
            enctype="multipart/form-data"
        >
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" id="id_field" x-model="selected_id">
        <input type="hidden" name="avatar_url" id="avatar_url_field" value="<?php echo e(old('avatar_url')); ?>">
        <input type="hidden" name="id_user" id="id_user_field" value="<?php echo e(old('id_user')); ?>">
        <input type="hidden" name="_method" id="_method_field" value="<?php echo e(old('id') ? 'PUT' : 'POST'); ?>">

        <div class="col-12">
            <div class="card shadow-sm ">
                <div class="card-header no-after py-4 d-flex justify-content-between align-items-center bg-warning bg-gradient bg-opacity-50">
                    <h2 class="fs-5 fw-medium text-black-50 m-0">Form Siswa</h2>
                    <a 
                    href="#"
                    role="button"
                    class="btn"
                    onclick="event.preventDefault();resetForm(`<?php echo e(route('admin.siswa.store')); ?>`)">
                        Clear
                    </a>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="" class="form-label fw-medium">
                            <small>Nama Lengkap</small>
                        </label>
                        <input type="text" id="nama_lengkap_field" class="form-control" name="nama_lengkap" value="<?php echo e(old('nama_lengkap')); ?>">
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'nama_lengkap'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label fw-medium">
                            <small>NISN</small>
                        </label>
                        <input type="text" id="nisn_field" class="form-control" name="nisn" value="<?php echo e(old('nisn')); ?>">
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'nisn'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                    </div>
                    
                    <div class="row">
                        <div class="col mb-3">
                            <label for="id_thak_masuk_field" class="form-label fw-medium">
                                <small>Tahun Masuk</small>
                            </label>
                            <select id="id_thak_masuk_field" class="form-select form-select-sm py-2" name="id_thak_masuk" value="<?php echo e(old('id_thak_masuk')); ?>">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($t->id); ?>"><?php echo e($t->nama_tahun); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </select>
                            <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'id_thak_masuk'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                        </div>
                        
                        <div class="col mb-3">
                            <label for="id_kelas_field" class="form-label fw-medium">
                                <small>Kelas</small>
                            </label>
                            <select id="id_kelas_field" class="form-select form-select-sm py-2" name="id_kelas" value="<?php echo e(old('id_kelas')); ?>">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($t->id); ?>"><?php echo e($t->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </select>
                            <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'id_kelas'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                        </div>
                    </div>

                    <div class="mb-3 my-0">
                        <label for="" class="form-label fw-bold">Lahir</label>
                        <div class="row">
                            <div class="col">
                                <label for="tempat_lahir_field" class="fw-medium form-label">
                                    <small>Tempat</small>
                                </label>
                                <input type="text" id="tempat_lahir_field" class="form-control" name="tempat_lahir" value="<?php echo e(old('tempat_lahir')); ?>">
                            </div>
                            <div class="col">
                                <label for="tanggal_lahir_field" class="fw-medium form-label">
                                    <small>Tanggal</small>
                                </label>
                                <input type="date" id="tanggal_lahir_field" class="form-control form-control-sm py-2" name="tanggal_lahir" value="<?php echo e(old('tanggal_lahir')); ?>">
                            </div>
                        </div>
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'tempat_lahir'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'tanggal_lahir'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                    </div>
                    <div class="form-group">
                        <div class="row" >
                            <div class="col mb-3">
                                <label for="status_field" class="form-label fw-medium">
                                    <small>Status Siswa</small>
                                </label>
                                <select id="riwayat_status_field" class="form-select form-select-sm py-2" name="status" value="<?php echo e(old('status')); ?>">
                                    <option value="NW">Baru</option>
                                    <option value="MM">Pindahan</option>
                                </select>
                                <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'status'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                            </div>
                            <div class="d-flex flex-wrap mb-3 col">
                                <label class="form-label fw-medium">
                                    <small>Gender</small>
                                </label>
                                <div class="input-group d-flex align-items-end" style="gap: 1rem;">
                                    <div class="form-check">
                                        <input type="radio" name="gender" id="gen_l" class="form-check-input" value="1" name="gender" <?php if(old('gender')==1): echo 'checked'; endif; ?>>
                                        <label for="gen_l" class="form-check-label">Laki-laki</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" name="gender" id="gen_p" class="form-check-input" value="0" name="gender" <?php if(old('gender')==0): echo 'checked'; endif; ?>>
                                        <label for="gen_p" class="form-check-label">Perempuan</label>
                                    </div>
                                    <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'gender'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    
                    
                    <div class="mb-3">
                        <label for="alamat_field" class="form-label fw-medium">
                            <small>Alamat</small>
                        </label>
                        <textarea id="alamat_field" cols="30" rows="4" class="form-control" name="alamat"><?php echo e(old('alamat')); ?></textarea>
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'alamat'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary py-2 bg-gradient w-100">Submit</button>
                        
                </div>
                
            </div>
        </div>

        <div class="col-12">
            <div class="card shadow-sm ">
                <div class="card-header py-4  bg-primary bg-gradient bg-opacity-50">
                    <h2 class="fs-5 fw-medium text-black-50 m-0">Info Akun</h2>
                    <div class="btn"></div>
                </div>
                <div class="card-body">
                    <div 
                        class="mb-3" 
                        x-data="{

                            img_url : `<?php echo e(old('avatar_url')); ?>`, 
                            img_preview : null,
                            img_initial : null,
                            is_img_load : false,
                            reset_preview() 
                            {
                                this.img_preview=null;
                                $refs.img_upload.value=null;
                            },
                            async get_img() 
                            {
                                this.reset_preview();
                                
                                
                                const res1=await fetch(`/files/images/users/default`)
                                const blob1=await res1.blob();
                                this.img_initial=URL.createObjectURL(blob1);
                                
                                if(this.img_url)
                                {
                                    const url=`id/${id_user}/${this.img_url==''?'p':this.img_url}` 
                                    const res2=await fetch(`/files/images/users/${url}`)
                                    const blob2=await res2.blob();
                                    this.img_preview=URL.createObjectURL(blob2);

                                }


                            }
                        }"
                        x-init="get_img();$watch('img_url', _=>get_img()) "
                        x-ref="imgContainer"
                    >
                        <label for="" class="fw-bold form-label">Foto Profil</label>
                        <div class="w-50 mb-3 position-relative">
                            <img x-bind:src="img_preview || img_initial" alt="" class="w-100 d-block" style="aspect-ratio: 1/1;object-fit: cover;">
                            <button 
                            type="button" 
                            class="btn btn-danger position-absolute p-0 w-25 rounded-pill" 
                            style="top: 0px; right: 0px;aspect-ratio: 1/1;transform: translate(50%, -50%)"
                            x-show="img_preview!=null"
                            x-on:click="reset_preview">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <input 
                        type="file" 
                        x-ref="img_upload"  
                        id="avatar_field" 
                        class="form-control-file form-control-file-sm d-block" 
                        x-on:change="img_preview=URL.createObjectURL(event.target.files[0])"
                        name="avatar">
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'avatar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>

                    </div>
                    <div class="mb-3">
                        <label for="" class="form-label fw-medium">
                            <small>Email</small>
                        </label>
                        <input type="text" id="email_field" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'email'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        </form>
    </div>
</div>

<script>
    const deleteForm=document.getElementById('form-delete');
    const formSiswa=document.getElementById('form-siswa');
    const methodField=document.getElementById('_method_field');
    const fields=['nama_lengkap', 'nisn', 'id_thak_masuk', 'id_kelas', 'tempat_lahir', 'tanggal_lahir', 'riwayat_status', 'email', 'alamat', 'avatar_url', 'id_user'];
    const fieldEls=Object.fromEntries(fields.map(key=>[key, document.getElementById(`${key}_field`)]))
    const genderFields=document.querySelectorAll('input[name="gender"]')

    const students=<?php echo json_encode($students->items(), 15, 512) ?>

    

    function editForm(id, route, userId) {
        const data=Alpine.$data(document.querySelector('[x-ref="mainContainer"]'))
        const student=students.filter(c => c.id==id)
        const form=student[0]
        data.id_user=userId;
        

        formSiswa.action=route;
        methodField.value='PUT';
        Object.keys(fieldEls).forEach(key=>{
            fieldEls[key].value=form[key]
        })
        genderFields.forEach(gf=>{
            gf.checked=gf.value==form['gender']
        })
        updateImgURL(form['avatar_url'])
        
    }
    const submitDeleteForm=()=>deleteForm.submit()
    const setDeleteForm=route=>deleteForm.action=route;

    function resetForm(route)
    {
        const data=Alpine.$data(document.querySelector('[x-ref="mainContainer"]'))
        Object.keys(fieldEls).forEach(key=>{
            fieldEls[key].value=null
        })
        genderFields.forEach(gf=>{
            gf.checked=false
        })
        formSiswa.action=route;
        methodField.value='POST';
        data.selected_id=null;
    }
    function updateImgURL(url)
    {
        const data=Alpine.$data(document.querySelector('[x-ref="imgContainer"]'))
        data.img_url=url;
        
    }
    
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arvin/riset/laravel/resources/views/admin/siswa/index.blade.php ENDPATH**/ ?>