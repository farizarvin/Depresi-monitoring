<?php $__env->startSection('title', 'Index Tahun Akademik'); ?>
<?php $__env->startSection('content_header'); ?>
    <div class="row justify-content-center">
        <div class="col-10">
            <h1 class="m-0">Tahun Akademik</h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="row g-4 justify-content-center"  x-data="{selected_id : `<?php echo e(old('id')); ?>`}">
    <div class="col-12 col-lg-8">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-success bg-gradient bg-opacity-50 no-after p-4">
                <h6 class="m-0 fw-medium fs-5 text-black-50 mb-3">Daftar Tahun Akademik</h6>
                <form method="GET" class="row g-2 align-items-center">
                    <div class="col-12 col-md-8">
                        <input type="text" name="search" class="form-control" placeholder="Cari tahun akademik (contoh: 2026)..." value="<?php echo e($search ?? ''); ?>">
                    </div>
                    <div class="col-8 col-md-3">
                        <select name="status" class="form-select">
                            <option value="">Semua Status</option>
                            <option value="current" <?php echo e($statusFilter == 'current' ? 'selected' : ''); ?>>Current</option>
                            <option value="active" <?php echo e($statusFilter == 'active' ? 'selected' : ''); ?>>Opened</option>
                            <option value="inactive" <?php echo e($statusFilter == 'inactive' ? 'selected' : ''); ?>>Closed</option>
                        </select>
                    </div>
                    <div class="col-4 col-md-1">
                        <button type="submit" class="btn btn-warning w-100">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
            </div>
            <div class="card-body p-4">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover shadow-none">
                        <thead class="text-black-50">
                            <tr>
                                <th scope="col" class="text-center py-3 fw-medium">No</th>
                                <th scope="col" class="py-3 fw-medium">Periode</th>
                                <th scope="col" class="py-3 fw-medium">Tanggal Mulai</th>
                                <th scope="col" class="py-3 fw-medium">Tanggal Selesai</th>
                                <th scope="col" class="py-3 fw-medium">Status</th>
                                <th scope="col" class="py-3 fw-medium" style="width: 120px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr 
                                class=""
                                :class="{'table-active' : (selected_id==<?php echo e($row->id); ?>) }">
                                    <td class="text-center"><?php echo e($i + 1); ?></td>
                                    <td><?php echo e($row->nama_tahun); ?></td>
                                    <td><?php echo e($row->tanggal_mulai); ?></td>
                                    <td><?php echo e($row->tanggal_selesai); ?></td>
                                    <td>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($row->current): ?>
                                            <span class="badge rounded-pill bg-success bg-opacity-75">current</span>
                                        <?php elseif($row->status): ?>
                                            <span class="badge rounded-pill bg-primary bg-opacity-75">opened</span>
                                        <?php else: ?>
                                            <span class="badge rounded-pill bg-danger bg-opacity-75">closed</span>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        
                                    </td>
                                    <td>
                                        <div class="d-flex gap-1">
                                            <a 
                                            href="#" 
                                            role="button"
                                            class="btn btn-outline-warning btn-sm"
                                            onclick="event.preventDefault();editForm('<?php echo e($row->id); ?>', `<?php echo e(route('admin.tahun-akademik.update', ['tahun_akademik'=>$row->id])); ?>`)"
                                            x-on:click="selected_id=<?php echo e($row->id); ?>;">
                                                <i class="fas fa-edit"></i>
                                            </a>

                                            <a 
                                            href="#"
                                            role="button"
                                            class="btn btn-outline-danger btn-sm"
                                            onclick="
                                            event.preventDefault();
                                            setDeleteForm(`<?php echo e(route('admin.tahun-akademik.destroy', ['tahun_akademik'=>$row->id])); ?>`);
                                            window.dispatchEvent(new CustomEvent('swal:confirm', {detail : {
                                                title : 'Konfirmasi hapus data',
                                                text : 'Apakah anda yakin ingin menghapus tahun akademik ini?',
                                                icon : 'warning',
                                                method : submitDeleteForm,
                                            }}))">
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="bg-light-subtle text-center text-black-50 py-4">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($search || $statusFilter): ?>
                                            <i class="fas fa-search fa-2x mb-2 text-muted"></i>
                                            <div>Tidak ditemukan tahun akademik yang sesuai</div>
                                            <small class="text-muted">Coba ubah kata kunci pencarian atau filter</small>
                                        <?php else: ?>
                                            <i class="fas fa-inbox fa-2x mb-2 text-muted"></i>
                                            <div>Belum ada tahun akademik</div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                </tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer py-4 px-4">
                <div class="d-flex justify-content-left">
                    <?php echo e($academicYears->links()); ?>

                </div>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-4">
        <div class="card shadow-sm">
            <div class="card-header no-after py-4 d-flex justify-content-between align-items-center bg-warning bg-gradient bg-opacity-50">
                <h2 class="fs-5 fw-medium m-0 text-black-50">Form Tahun Akademik</h2>
                <a 
                href="#"
                role="button"
                class="btn"
                onclick="event.preventDefault();resetForm(`<?php echo e(route('admin.tahun-akademik.store')); ?>`)">
                    Clear
                </a>
            </div>
            <div class="card-body">
                <form method="post" class="d-none" id="form-delete">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
                <form 
                <?php if(old('id')==null): ?> 
                    action="<?php echo e(route('admin.tahun-akademik.store')); ?>" 
                <?php else: ?>  
                    action="<?php echo e(route('admin.tahun-akademik.update', ['tahun_akademik'=>old('id')])); ?>"
                <?php endif; ?>
                method="POST"
                class="w-100" id="form-tahun-akademik">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" id="id_field" x-model="selected_id">
                <input type="hidden" name="_method" id="_method_field" value="<?php echo e(old('id')==null ? 'POST' : 'PUT'); ?>">
                <div class="mb-3">
                    <label class="form-label fw-medium" for="tahun_mulai_field">
                        <small>Periode Tahun</small>
                    </label>
                    <div class="input-group">
                        <input type="text" class="form-control" id="tahun_mulai_field" placeholder="Awal" name="tahun_mulai" value="<?php echo e(old('tahun_mulai')); ?>">
                        <input type="text" class="form-control" id="tahun_akhir_field" placeholder="Akhir" name="tahun_akhir" value="<?php echo e(old('tahun_akhir')); ?>">
                        
                            <div class="input-group-text">
                                <input type="hidden" name="status" value="0">
                                <input type="checkbox" id="status_field" name="status" value="1" <?php if(old('status')): echo 'checked'; endif; ?>>
                                
                            </div>
                        
                        
                    </div>
                    <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'periode'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'tahun_mulai'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'tahun_akhir'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'status'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                </div>
                
                
                <div class="mb-3">
                    <label class="form-label fw-bold" for="tanggal_mulai_field">
                        <small>Tanggal</small>
                    </label>
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label fw-medium" for="tanggal_mulai_field" class="font-weight-normal">
                                <small>Mulai</small>
                            </label>
                            <input type="date" class="form-control form-control-sm py-3" id="tanggal_mulai_field" name="tanggal_mulai" value="<?php echo e(old('tanggal_mulai')); ?>">
                            <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'tanggal_mulai'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                        </div>
                        
                        <div class="col-6">
                            <label class="form-label fw-medium" for="tanggal_selesai_field" class="font-weight-normal">
                                <small>Selesai</small>
                            </label>
                            <input type="date" class="form-control form-control-sm py-3" id="tanggal_selesai_field" name="tanggal_selesai" value="<?php echo e(old('tanggal_selesai')); ?>">
                            <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'tanggal_selesai'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="mb-3 form-check">
                    <input type="hidden" name="current" value="0">
                    <input type="checkbox"  id="current_field" class="form-check-input" name="current" value="1" <?php if(old('current')): echo 'checked'; endif; ?>>
                    <label for="" class="fw-medium">
                        <small>Set as current</small>
                    </label>
                    <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'current'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>

                </div>
                <button type="submit" class="btn btn-primary w-100">Simpan</button>
            </form>
            </div>
           
        </div>
    </div>
</div>
<script>
    const deleteForm=document.getElementById('form-delete');
    const formTahunAkademik=document.getElementById('form-tahun-akademik');
    const methodField=document.getElementById('_method_field');
    const fields=['tahun_mulai', 'tahun_akhir', 'status', 'current', 'tanggal_mulai', 'tanggal_selesai', 'id'];
    const fieldEls=Object.fromEntries(fields.map(key=>[key, document.getElementById(`${key}_field`)]))
    const academicYears=<?php echo json_encode($academicYears->items(), 15, 512) ?>

    

    function editForm(id, route) {
        const academicYear=academicYears.filter(c => c.id==id)
        const form=academicYear[0]

        formTahunAkademik.action=route;
        methodField.value='PUT';
        Object.keys(fieldEls).forEach(key=>{
            fieldEls[key].value=form[key]
        })
        fieldEls['current'].value="1";
        fieldEls['status'].value="1";
        fieldEls['current'].checked=form['current']
        fieldEls['status'].checked=form['status']
    }
    const submitDeleteForm=()=>deleteForm.submit()
    const setDeleteForm=route=>deleteForm.action=route;

    function resetForm(route)
    {
        Object.keys(fieldEls).forEach(key=>{
            fieldEls[key].value=null
        })
        fieldEls['current'].checked=false
        fieldEls['status'].checked=false
        formTahunAkademik.action=route;
        methodField.value='POST'
    }
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arvin/riset/laravel/resources/views/admin/tahun_akademik/index.blade.php ENDPATH**/ ?>