<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
    <!-- Close Button for Mobile -->
    <button class="sidebar-close" id="sidebarClose">
        <i class="bi bi-x-lg"></i>
    </button>
    <!-- User Container -->
    <?php
        $currentSiswa = Illuminate\Support\Facades\Auth::user()->siswa ?? null;
        $namaLengkap = $currentSiswa ? $currentSiswa->nama_lengkap : 'Siswa';
        // Generate initials from name (e.g., "John Doe" -> "JD")
        $nameParts = explode(' ', $namaLengkap);
        $initials = '';
        foreach (array_slice($nameParts, 0, 2) as $part) {
            $initials .= strtoupper(substr($part, 0, 1));
        }
    ?>
    <div class="user-container">
        <div class="user-profile">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(Illuminate\Support\Facades\Auth::user()->avatar_url): ?>
                <img src="<?php echo e(route('files.users.image', ['path' => Illuminate\Support\Facades\Auth::user()->id . '/' . Illuminate\Support\Facades\Auth::user()->avatar_url])); ?>" alt="Profile" class="user-avatar" style="object-fit: cover;">
            <?php else: ?>
                <div class="user-avatar"><?php echo e($initials); ?></div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <div class="user-info">
                <p class="user-name"><?php echo e($namaLengkap); ?></p>
                <p class="user-role">Siswa</p>
            </div>
        </div>
        <div class="welcome-divider">
            <p class="welcome-text">Selamat Datang! 👋</p>
        </div>
    </div>

    <!-- Navigation Menu -->
    <nav class="nav-menu">
        <ul class="list-unstyled">
            <li class="nav-item">
                <?php echo $__env->make('components.buttons.button-sidebar', [
                    'href' => '/siswa/dashboard',
                    'icon' => 'bi-grid-fill',
                    'text' => 'Dashboard',
                    'active' => request()->is('siswa/dashboard')
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    </li>
                                    <li class="nav-item">
                <?php echo $__env->make('components.buttons.button-sidebar', [
                    'href' => '/siswa/presensi',
                    'icon' => 'bi-calendar-check',
                    'text' => 'Absensi',
                    'active' => request()->is('siswa/presensi')
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </li>
            
            <li class="nav-item">
                <?php echo $__env->make('components.buttons.button-sidebar', [
                    'href' => '/siswa/statistik',
                    'icon' => 'bi-bar-chart-fill',
                    'text' => 'Statistik',
                    'active' => request()->is('siswa/statistik')
                ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php
                $siswa = Illuminate\Support\Facades\Auth::user()->siswa;
                $showSelfCare=$siswa->is_depressed || $siswa->need_selfcare;
                // $hasFilledDass = $siswa && $siswa->kuesionerResults()->exists();
                // $showSelfCare = false;

                // if ($hasFilledDass) {
                //     $latestResult = $siswa->kuesionerResults()->latest()->first();
                //     if ($latestResult) {
                //         $scores = $latestResult->calculateScores();
                //         // Thresholds for Normal: Depression <= 9, Anxiety <= 7, Stress <= 14
                //         if ($scores['depression'] <= 9 && $scores['anxiety'] <= 7 && $scores['stress'] <= 14) {
                //             $showSelfCare = true;
                //         }
                //     }
                // }
            ?>

            <li class="nav-item">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($showSelfCare): ?>
                    <?php echo $__env->make('components.buttons.button-sidebar', [
                        'href' => '/siswa/diaryku',
                        'icon' => 'bi-journal-medical',
                        'text' => 'Self Care',
                        'active' => request()->is('siswa/diaryku')
                    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </li>
        </ul>
    </nav>

    <!-- Logout Section -->
    <div class="logout-section">
        <form action="<?php echo e(route('logout')); ?>" method="POST" style="display: inline;">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn-logout" style="background: #dc3545; color: white; border: none; width: 100%; text-align: left; display: flex; align-items: center; cursor: pointer; padding: 10px 15px; border-radius: 10px; transition: background 0.3s;">
                <i class="bi bi-box-arrow-right"></i>
                <span style="margin-left: 10px; font-weight: 500;">Keluar</span>
            </button>
        </form>
    </div>
</aside>
<?php /**PATH /Users/arvin/riset/laravel/resources/views/components/sidebar.blade.php ENDPATH**/ ?>