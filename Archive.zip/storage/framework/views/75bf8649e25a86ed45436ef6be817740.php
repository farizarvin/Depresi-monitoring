<?php $__env->startSection('title', 'Detail Laporan Mood - ' . $siswa->nama_lengkap); ?>

<?php
    $pageTitle = 'Detail Laporan Mood';
    $pageSubtitle = $siswa->nama_lengkap;
?>

<?php $__env->startSection('content'); ?>
<!-- Back Button & Export -->
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
    <a href="<?php echo e(route('guru.mood.index')); ?>" class="btn btn-outline-secondary rounded-pill px-4">
        <i class="bi bi-arrow-left me-2"></i> Kembali
    </a>
    <a href="<?php echo e(route('guru.mood.export', $siswa->id)); ?>" class="btn btn-danger rounded-pill px-4">
        <i class="bi bi-file-earmark-pdf me-2"></i> Download PDF
    </a>
</div>

<!-- Student Info Card -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
    <div class="card-body p-4">
        <div class="d-flex align-items-center gap-3">
            <div class="rounded-circle bg-primary bg-opacity-10 d-flex align-items-center justify-content-center" style="width: 60px; height: 60px;">
                <span class="fs-4 fw-bold text-primary"><?php echo e(strtoupper(substr($siswa->nama_lengkap, 0, 2))); ?></span>
            </div>
            <div>
                <h4 class="mb-1 fw-bold"><?php echo e($siswa->nama_lengkap); ?></h4>
                <p class="text-muted mb-0">NISN: <?php echo e($siswa->nisn); ?></p>
            </div>
        </div>
    </div>
</div>

<!-- DASS-21 Results -->
<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($dassScores): ?>
<div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
    <div class="card-header bg-white border-0 pt-4 px-4">
        <h5 class="mb-1 fw-bold"><i class="bi bi-clipboard2-pulse me-2 text-primary"></i>Hasil DASS-21</h5>
        <p class="text-muted small mb-0">Tanggal pengisian: <?php echo e($dassScores['date']); ?></p>
    </div>
    <div class="card-body p-4">
        <div class="row g-4 text-center">
            <!-- Depression -->
            <div class="col-md-4">
                <div class="p-3 rounded bg-light h-100">
                    <h6 class="text-uppercase text-muted fw-bold small mb-2">Tingkat Depresi</h6>
                    <h3 class="fw-bold mb-2"><?php echo e($dassScores['depression']); ?></h3>
                    <?php
                        $dColor = match($dassScores['depression_label']) {
                            'Normal' => 'success',
                            'Ringan' => 'info',
                            'Sedang' => 'warning',
                            default => 'danger',
                        };
                    ?>
                    <span class="badge bg-<?php echo e($dColor); ?> rounded-pill px-3 py-2"><?php echo e($dassScores['depression_label']); ?></span>
                </div>
            </div>
            <!-- Anxiety -->
            <div class="col-md-4">
                <div class="p-3 rounded bg-light h-100">
                    <h6 class="text-uppercase text-muted fw-bold small mb-2">Tingkat Kecemasan</h6>
                    <h3 class="fw-bold mb-2"><?php echo e($dassScores['anxiety']); ?></h3>
                    <?php
                        $aColor = match($dassScores['anxiety_label']) {
                            'Normal' => 'success',
                            'Ringan' => 'info',
                            'Sedang' => 'warning',
                            default => 'danger',
                        };
                    ?>
                    <span class="badge bg-<?php echo e($aColor); ?> rounded-pill px-3 py-2"><?php echo e($dassScores['anxiety_label']); ?></span>
                </div>
            </div>
            <!-- Stress -->
            <div class="col-md-4">
                <div class="p-3 rounded bg-light h-100">
                    <h6 class="text-uppercase text-muted fw-bold small mb-2">Tingkat Stres</h6>
                    <h3 class="fw-bold mb-2"><?php echo e($dassScores['stress']); ?></h3>
                    <?php
                        $sColor = match($dassScores['stress_label']) {
                            'Normal' => 'success',
                            'Ringan' => 'info',
                            'Sedang' => 'warning',
                            default => 'danger',
                        };
                    ?>
                    <span class="badge bg-<?php echo e($sColor); ?> rounded-pill px-3 py-2"><?php echo e($dassScores['stress_label']); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- DASS-21 Answers Table -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
    <div class="card-header bg-white border-0 pt-4 px-4 d-flex justify-content-between align-items-center">
        <h5 class="mb-0 fw-bold"><i class="bi bi-list-check me-2 text-primary"></i>Jawaban DASS-21</h5>
        <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#dassAnswersCollapse">
            <i class="bi bi-chevron-down"></i> Toggle
        </button>
    </div>
    <div class="collapse show" id="dassAnswersCollapse">
        <div class="card-body p-4 pt-0">
            <div class="table-responsive">
                <table class="table table-sm table-hover">
                    <thead class="bg-light">
                        <tr>
                            <th class="py-2" style="width: 50px;">#</th>
                            <th class="py-2">Pertanyaan</th>
                            <th class="py-2 text-center" style="width: 100px;">Kategori</th>
                            <th class="py-2 text-center" style="width: 120px;">Jawaban</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $dassAnswers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-muted"><?php echo e($ans['no']); ?></td>
                            <td><?php echo e($ans['question']); ?></td>
                            <td class="text-center">
                                <?php
                                    $catBadge = match($ans['category']) {
                                        'Depression' => 'bg-danger bg-opacity-10 text-danger',
                                        'Anxiety' => 'bg-warning bg-opacity-10 text-warning',
                                        'Stress' => 'bg-info bg-opacity-10 text-info',
                                        default => 'bg-secondary bg-opacity-10 text-secondary',
                                    };
                                ?>
                                <span class="badge <?php echo e($catBadge); ?> rounded-pill"><?php echo e(substr($ans['category'], 0, 1)); ?></span>
                            </td>
                            <td class="text-center">
                                <span class="badge bg-secondary bg-opacity-10 text-dark"><?php echo e($ans['answer']); ?> - <?php echo e($ans['answer_text']); ?></span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
<div class="alert alert-info" role="alert">
    <i class="bi bi-info-circle me-2"></i> Siswa ini belum mengisi kuesioner DASS-21.
</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<!-- 14-Day Mood History -->
<div class="card border-0 shadow-sm mb-4" style="border-radius: 15px;">
    <div class="card-header bg-white border-0 pt-4 px-4">
        <h5 class="mb-1 fw-bold"><i class="bi bi-calendar-week me-2 text-primary"></i>Riwayat Mood (14 Hari Terakhir)</h5>
        <p class="text-muted small mb-0">Data presensi dan prediksi emosi dari kamera</p>
    </div>
    <div class="card-body p-4">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($moodHistory) > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="bg-light">
                    <tr>
                        <th class="py-2">Tanggal</th>
                        <th class="py-2">Waktu</th>
                        <th class="py-2 text-center">Status</th>
                        <th class="py-2 text-center">Prediksi Kamera</th>
                        <th class="py-2">Catatan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $moodHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="fw-medium"><?php echo e($mood['tanggal']); ?></td>
                        <td class="text-muted"><?php echo e($mood['waktu']); ?></td>
                        <td class="text-center">
                            <?php
                                $statusBadge = match($mood['status']) {
                                    'H' => 'bg-success',
                                    'I' => 'bg-warning',
                                    'S' => 'bg-danger',
                                    default => 'bg-secondary',
                                };
                                $statusText = match($mood['status']) {
                                    'H' => 'Hadir',
                                    'I' => 'Izin',
                                    'S' => 'Sakit',
                                    default => 'Alpha',
                                };
                            ?>
                            <span class="badge <?php echo e($statusBadge); ?> rounded-pill"><?php echo e($statusText); ?></span>
                        </td>
                        <td class="text-center">
                            <span class="badge bg-primary bg-opacity-10 text-primary rounded-pill px-3"><?php echo e($mood['emotion_label']); ?></span>
                        </td>
                        <td class="text-muted small" style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?php echo e($mood['catatan']); ?>">
                            <?php echo e(Str::limit($mood['catatan'], 50)); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-5 text-muted">
            <i class="bi bi-calendar-x display-4 d-block mb-3"></i>
            Tidak ada data presensi dalam 14 hari terakhir.
        </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guru', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arvin/riset/laravel/resources/views/guru/mood/detail.blade.php ENDPATH**/ ?>