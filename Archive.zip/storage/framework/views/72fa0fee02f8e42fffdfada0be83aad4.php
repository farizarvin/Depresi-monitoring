<div>
    <div class="row justify-content-center g-4">
        
        <!-- Header / Filters -->
        <div class="col-12 mb-4">
            <div class="card shadow-sm">
                <div class="card-body d-flex flex-wrap align-items-center justify-content-between gap-3">
                    <div>
                        <h1 class="h4 m-0 text-gray-800">Dashboard</h1>
                        <p class="m-0 text-muted small">Panel Administrasi</p>
                    </div>
                    <div class="d-flex gap-2">
                        <!-- Academic Year Filter -->
                        <select wire:model.live="selectedAcademicYear" class="form-select w-auto">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $this->academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($year->id); ?>"><?php echo e($year->nama_tahun); ?> <?php echo e($year->current ? '(Aktif)' : ''); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                        
                        <!-- Month Filter -->
                        <select wire:model.live="selectedMonth" class="form-select w-auto">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = range(1, 12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($m); ?>"><?php echo e(\Carbon\Carbon::create()->month($m)->translatedFormat('F')); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <!-- Schedule Column -->
        <div class="col-12 col-md-4 col-xl-3 mb-4">
            <form wire:submit="saveSchedule">
                <div class="accordion accordion-flush border" id="accordionSchedule">
                    <div class="accordion-item">
                        <h2 class="accordion-header bg-success bg-gradient">
                            <button class="accordion-button fs-5 fw-bold text-primary py-4" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne">
                                Jadwal Harian
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionSchedule">
                            <div class="accordion-body">
                                Atur jadwal masuk dan pulang sekolah untuk setiap jenjang.
                            </div>
                        </div>
                        <hr class="m-0">
                        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 px-3 py-3">
                            <div class="w-100">
                                <select wire:model.live="grade" class="form-select form-select-sm bg-light">
                                    <option value="1">Jenjang 1</option>
                                    <option value="2">Jenjang 2</option>
                                    <option value="3">Jenjang 3</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($currentSchedule)): ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dayName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed d-flex align-items-center" type="button" data-bs-toggle="collapse" data-bs-target="#collapseDay<?php echo e($key); ?>">
                                        <!-- Checkbox for holiday? Data structure dependent -->
                                        <!-- Assuming structure: hari_libur array of ints -->
                                        <div class="form-check me-2" onclick="event.stopPropagation()">
                                            <input type="checkbox" class="form-check-input" 
                                                   wire:model="currentSchedule.hari_libur" 
                                                   value="<?php echo e($key); ?>">
                                        </div>
                                        <span class="fs-6 fw-medium text-black-50"><?php echo e($dayName); ?></span>
                                    </button>
                                </h2>
                                <div id="collapseDay<?php echo e($key); ?>" class="accordion-collapse collapse" data-bs-parent="#accordionSchedule" wire:ignore.self>
                                    <div class="accordion-body bg-light-subtle">
                                        <div class="row align-items-end justify-content-e px-2">
                                            <div class="col p-0">
                                                <label class="fw-medium mb-1 fs-6"><small>Mulai</small></label>
                                                <input type="time" class="form-control rounded-end-0 border-end-0"
                                                       wire:model="currentSchedule.jadwal.<?php echo e($key); ?>.jam_mulai">
                                            </div>
                                            <div class="col p-0">
                                                <label class="fw-medium mb-1 fs-6"><small>Akhir</small></label>
                                                <input type="time" class="form-control rounded-0 border-end-0"
                                                       wire:model="currentSchedule.jadwal.<?php echo e($key); ?>.jam_akhir">
                                            </div>
                                            <div class="w-auto p-0">
                                                <button type="submit" class="btn btn-pill btn-primary rounded-start-0">Save</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Calendar Column -->
        <div class="col-12 col-md-8 col-xl-6 mb-4">
            <div class="card">
                <div class="card-header py-0 no-after d-flex justify-content-between align-items-center bg-success bg-gradient bg-opacity-50">
                    <div class="py-4">
                        <h1 class="fs-5 m-0 d-block text-black-50">
                            <strong class="text-black-50"><?php echo e(\Carbon\Carbon::create()->month($selectedMonth)->translatedFormat('F')); ?></strong> 
                            - <span class="font-weight-normal text-black-50"><?php echo e($this->calendarYear); ?></span>
                        </h1>
                    </div>
                    
                    <div class="form-group d-flex m-0">
                        <button type="button" wire:click="$toggle('isEditing')" class="btn btn-sm <?php echo e($isEditing ? 'btn-danger' : 'btn-warning'); ?>">
                            <i class="fas <?php echo e($isEditing ? 'fa-times' : 'fa-edit'); ?>"></i> <?php echo e($isEditing ? 'Cancel' : 'Edit'); ?>

                        </button>
                    </div>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" style="table-layout: fixed;">
                            <thead class="bg-light">
                                <tr>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th class="col text-center <?php echo e(in_array($i, [0, 6]) ? 'text-secondary' : ''); ?>"><?php echo e($header); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $this->calendars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($loop->first && isset($week[0]['day']) && $week[0]['day'] > 0): ?>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($x = 0; $x < $week[0]['day']; $x++): ?>
                                                <td class="col p-0 bg-light"></td>
                                            <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="col p-0" style="box-sizing: border-box;">
                                                <?php
                                                    $dateStr = sprintf('%04d-%02d-%02d', $this->calendarYear, $selectedMonth, $day['date']);
                                                    $isVacant = $this->isVacant($dateStr); // N+1? No, iterates collections in memory
                                                    $isSelected = $this->isDateSelected($dateStr);
                                                    $isWeekend = in_array($day['day'], [0, 6]);
                                                ?>

                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isWeekend): ?>
                                                    <button type="button" class="w-100 h-100 px-0 rounded-0 border-0 position-relative btn btn-outline-light text-muted" disabled>
                                                        <div class="<?php echo e($isVacant ? 'bg-warning-subtle' : ''); ?>"><?php echo e($day['date']); ?></div>
                                                    </button>
                                                <?php else: ?>
                                                    <button type="button" 
                                                            wire:click="selectDate('<?php echo e($dateStr); ?>')"
                                                            class="w-100 h-100 px-0 rounded-0 border-0 position-relative <?php echo e($isSelected ? 'btn bg-light' : 'btn btn-outline-light text-body'); ?>">
                                                        <div class="<?php echo e($isVacant ? 'bg-warning-subtle' : ''); ?>"><?php echo e($day['date']); ?></div>
                                                    </button>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                                        
                                        <?php 
                                            $lastDay = end($week)['day'];
                                        ?>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lastDay < 6): ?>
                                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($x = $lastDay + 1; $x <= 6; $x++): ?>
                                                <td class="col p-0 bg-light"></td>
                                            <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Event List -->
                    <ul class="list-unstyled mt-3">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $this->vacations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vac): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-item mb-2">
                                <div class="card bg-warning-subtle text-sm">
                                    <div class="card-body no-after d-flex justify-content-between align-items-center">
                                        <div>
                                            <p class="m-0 font-weight-semibold text-black-50" style="font-size: 14px;">
                                                <span class="fw-bold"><?php echo e(\Carbon\Carbon::parse($vac->tanggal_mulai)->format('d M')); ?> 
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($vac->tanggal_mulai != $vac->tanggal_selesai): ?>
                                                    - <?php echo e(\Carbon\Carbon::parse($vac->tanggal_selesai)->format('d M')); ?>

                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </span> 
                                                : <?php echo e($vac->ket); ?>

                                            </p>
                                        </div>
                                        <button wire:click="deleteEvent(<?php echo e($vac->id); ?>)" class="text-black-50 btn btn-sm"><i class="fas fa-times"></i></button>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Add Event & Config Column -->
        <div class="col-12 col-md-12 col-xl-3 mb-4">
            <!-- Add Event Form -->
            <form wire:submit="saveEvent">
                <div class="card shadow-sm mb-4">
                    <div class="card-header py-4 bg-warning bg-gradient bg-opacity-50">
                        <h2 class="fs-5 fw-medium m-0 text-black-50">Add Event</h2>
                    </div>
                    <div class="card-body">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(empty($selectedDates)): ?>
                            <div class="alert alert-info py-2 small">
                                <i class="fas fa-info-circle"></i> Klik tombol <b>Edit</b> di kalender lalu pilih tanggal (range).
                            </div>
                        <?php else: ?>
                            <div class="mb-3">
                                <label class="form-label small fw-bold">Tanggal Terpilih:</label>
                                <div class="form-control form-control-sm bg-light">
                                    <?php echo e(\Carbon\Carbon::parse($selectedDates[0])->format('d M Y')); ?>

                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($selectedDates) > 1): ?>
                                        s/d <?php echo e(\Carbon\Carbon::parse($selectedDates[1])->format('d M Y')); ?>

                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                        <div class="mb-3">
                            <label class="form-label fw-medium"><small>Keterangan Event</small></label>
                            <textarea wire:model="newEventDescription" rows="3" class="form-control" placeholder="Deskripsi event..."></textarea>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['newEventDescription'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-medium d-block"><small>Jenjang</small></label>
                            <div class="d-flex gap-3">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = [1,2,3]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" wire:model="newEventJenjang" value="<?php echo e($j); ?>" id="j<?php echo e($j); ?>">
                                        <label class="form-check-label" for="j<?php echo e($j); ?>"><?php echo e($j); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['newEventJenjang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger small"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-primary w-100" <?php echo e(empty($selectedDates) ? 'disabled' : ''); ?>>Tambah</button>
                    </div>
                </div>
            </form>

            <!-- Config Form -->
            <form wire:submit="saveDiaryConfig">
                <div class="card shadow-sm">
                    <div class="card-header py-4 bg-info bg-gradient bg-opacity-50">
                        <h2 class="fs-5 fw-medium m-0 text-black-50">Rekap Range</h2>
                    </div>
                    <div class="card-body">
                        <label class="form-label fw-medium"><small>Rentang Hari</small></label>
                        <div class="input-group">
                            <input type="number" wire:model="diaryConfig.rentang" class="form-control">
                            <div class="input-group-text fs-6"><small>days</small></div>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /Users/arvin/riset/laravel/resources/views/livewire/admin/dashboard.blade.php ENDPATH**/ ?>