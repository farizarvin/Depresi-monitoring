<!-- Header -->
<header class="main-header">
    <!-- Mobile Menu Toggle (di dalam header) -->
    <button class="mobile-menu-toggle" id="mobileMenuToggle">
        <i class="bi bi-list"></i>
    </button>

    <div class="header-title">
        <h1><?php echo e($title); ?></h1>
        <p class="header-subtitle"><?php echo e($subtitle); ?></p>
    </div>
</header>
<?php /**PATH /Users/arvin/riset/laravel/resources/views/components/header.blade.php ENDPATH**/ ?>