<?php $__env->startSection('title', 'Index Siswa'); ?>
<?php $__env->startSection('content_header'); ?>
    <div class="row justify-content-center">
        <div class="col-10">
            <h1 class="m-0">Kelas</h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


<div class="row g-4 justify-content-center"  x-data="{selected_id : `<?php echo e(old('id')); ?>`}">
    <div class="col-12 col-lg-8">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-success bg-gradient bg-opacity-50 no-after p-4">
                <div class="row align-items-center gy-2">
                    <div class="col-12 col-md-3">
                        <h6 class="m-0 fw-medium fs-5 text-black-50">Daftar Kelas</h6>
                    </div>
                    <div class="col-12 col-md-9">
                        <form method="GET" class="row g-2">
                            <div class="col-12 col-md-5">
                                <input type="text" name="search" class="form-control" placeholder="Cari nama kelas..." value="<?php echo e($search ?? ''); ?>">
                            </div>
                            <div class="col-6 col-md-3">
                                <select name="jenjang" class="form-select">
                                    <option value="">Semua Jenjang</option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $jenjangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenjang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($jenjang); ?>" <?php echo e($jenjangFilter == $jenjang ? 'selected' : ''); ?>>
                                            <?php echo e($jenjang); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </select>
                            </div>
                            <div class="col-6 col-md-3">
                                <select name="jurusan" class="form-select">
                                    <option value="">Semua Jurusan</option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($jurusan); ?>" <?php echo e($jurusanFilter == $jurusan ? 'selected' : ''); ?>>
                                            <?php echo e($jurusan); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </select>
                            </div>
                            <div class="col-12 col-md-1">
                                <button type="submit" class="btn btn-warning w-100">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="card-body p-4">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover shadow-none">
                        <thead class="text-black-50">
                            <tr>
                                <th scope="col" class="text-center py-3 fw-medium">No</th>
                                <th scope="col" class="py-3 fw-medium">Nama Kelas</th>
                                <th scope="col" class="py-3 fw-medium">Jenjang</th>
                                <th scope="col" class="py-3 fw-medium">Jurusan</th>
                                <th scope="col" class="py-3 fw-medium" style="width: 120px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr :class="{'table-active' : (selected_id==<?php echo e($row->id); ?>)}">
                                    <td class="text-center"><?php echo e($i + 1); ?></td>
                                    <td><?php echo e($row->nama); ?></td>
                                    <td><?php echo e($row->jenjang); ?></td>
                                    <td><?php echo e($row->jurusan); ?></td>
                                    <td class="">
                                        <div class="d-flex gap-1">
                                            <a 
                                            href="#" 
                                            role="button"
                                            class="btn btn-outline-warning btn-sm"
                                            onclick="event.preventDefault();editForm('<?php echo e($row->id); ?>', `<?php echo e(route('admin.kelas.update', ['kelas'=>$row->id])); ?>`)"
                                            x-on:click="selected_id=<?php echo e($row->id); ?>;"
                                            >
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a 
                                            href="#"
                                            role="button"
                                            class="btn btn-sm btn-outline-danger"
                                            onclick="
                                            event.preventDefault();
                                            setDeleteForm(`<?php echo e(route('admin.kelas.destroy', ['kelas'=>$row->id])); ?>`);
                                            window.dispatchEvent(new CustomEvent('swal:confirm', {detail : {
                                                title : 'Konfirmasi hapus data',
                                                text : 'Apakah anda yakin ingin menghapus kelas ini?',
                                                icon : 'warning',
                                                method : submitDeleteForm,
                                            }}))"
                                            >
                                                <i class="fas fa-trash-alt"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="bg-light-subtle text-center text-black-50 py-4">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($search || $jenjangFilter || $jurusanFilter): ?>
                                            <i class="fas fa-search fa-2x mb-2 text-muted"></i>
                                            <div>Tidak ditemukan data kelas yang sesuai</div>
                                            <small class="text-muted">Coba ubah kata kunci pencarian atau filter</small>
                                        <?php else: ?>
                                            <i class="fas fa-inbox fa-2x mb-2 text-muted"></i>
                                            <div>Belum ada data kelas</div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                </tr>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer py-4 px-4">
                <div class="d-flex justify-content-left">
                    <?php echo e($classes->links()); ?>

                </div>
            </div>
        </div>
        
    </div>
    <div class="col-12 col-lg-4">
        <div class="card shadow-sm">
            <div class="card-header no-after py-4 d-flex justify-content-between align-items-center bg-warning bg-gradient bg-opacity-50">
                <h2 class="h5 font-weight-bold text-black-50">Form Kelas</h2>
                <a 
                href="#"
                role="button"
                class="btn"
                onclick="event.preventDefault();resetForm(`<?php echo e(route('admin.kelas.store')); ?>`)">
                    Clear
                </a>
            </div>
            <div class="card-body">
                <form method="post" class="d-none" id="form-delete">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
                <form 
                <?php if(old('id')==null): ?>
                action="<?php echo e(route('admin.kelas.store')); ?>" 
                <?php else: ?>
                action="<?php echo e(route('admin.kelas.update', ['kelas'=>old('id')])); ?>" 
                <?php endif; ?>
                method="POST" id="form-kelas" class="col-12">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" id="id_field" x-model="selected_id">
                    <input type="hidden" name="_method" id="_method_field" value="<?php echo e(old('id') ? 'PUT' : 'POST'); ?>">
                    <div class="mb-3">
                        <label class="form-label fw-medium" for="nama_field">
                            <small>Nama</small>
                        </label>
                        <input type="text" id="nama_field" class="form-control" name="nama" value="<?php echo e(old('nama')); ?>">
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'nama'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-medium" for="jenjang_field">
                            <small>Jenjang</small>
                        </label>
                        <select class="form-select" id="jenjang_field" name="jenjang">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php for($i=1;$i<=3;$i++): ?>
                                <option value="<?php echo e($i); ?>" <?php if(old('jenjang')==$i): echo 'selected'; endif; ?>><?php echo e($i); ?></option>
                            <?php endfor; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </select>
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'jenjang'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-medium" for="">
                            <small>Jurusan</small>
                        </label>
                        <select id="jurusan_field" class="form-select" name="jurusan">
                            <option value="IPA" <?php if(old('jurusan')=='IPA'): echo 'selected'; endif; ?>>IPA</option>
                            <option value="IPS" <?php if(old('jurusan')=='IPS'): echo 'selected'; endif; ?>>IPS</option>
                        </select>
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'jurusan'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary bg-gradient w-100">Simpan</button>
                </form>
            </div>
            
        </div>
    </div>
</div>
<script>
    const deleteForm=document.getElementById('form-delete');
    const formKelas=document.getElementById('form-kelas');
    const namaField=document.getElementById('nama_field');
    const methodField=document.getElementById('_method_field');
    const jenjangField=document.getElementById('jenjang_field');
    const jurusanField=document.getElementById('jurusan_field');

    const classes=<?php echo json_encode($classes->items(), 15, 512) ?>

    const submitDeleteForm=()=>deleteForm.submit()
    const setDeleteForm=route=>deleteForm.action=route;
    function editForm(id, route) {
        const _class=classes.filter(c => c.id==id)
        const form=_class[0]

        formKelas.action=route;
        methodField.value='PUT';
        namaField.value=form.nama;
        jenjangField.value=form.jenjang;
        jurusanField.value=form.jurusan;
    }

    function resetForm(route)
    {
        namaField.value='';
        jenjangField.value='1';
        jurusanField.value='IPA';
        formKelas.action=route;
        methodField.value='POST'
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arvin/riset/laravel/resources/views/admin/kelas/index.blade.php ENDPATH**/ ?>