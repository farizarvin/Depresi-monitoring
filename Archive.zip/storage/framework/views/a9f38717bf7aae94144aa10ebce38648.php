<?php $__env->startSection('title', 'Laporan Mood Siswa'); ?>

<?php
    $pageTitle = 'Laporan Mood';
    $pageSubtitle = 'Monitor kondisi emosional siswa';
?>

<?php $__env->startSection('content'); ?>
<div class="card border-0 shadow-sm" style="border-radius: 15px;">
    <div class="card-body p-4">
        <!-- Header with info -->
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
            <div>
                <h5 class="mb-1 fw-bold">Daftar Siswa</h5>
                <p class="text-muted small mb-0">Klik nama siswa untuk melihat laporan lengkap</p>
            </div>
            </span>
        </div>

        <!-- Filter Form -->
        <form action="<?php echo e(route('guru.mood.index')); ?>" method="GET" class="mb-4">
            <div class="row g-3">
                <div class="col-12 col-md-4">
                    <div class="input-group">
                        <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
                        <input type="text" name="search" class="form-control border-start-0 ps-0" placeholder="Cari Nama atau NISN..." value="<?php echo e(request('search')); ?>">
                    </div>
                </div>
                <div class="col-6 col-md-2">
                    <select name="kelas" class="form-select" onchange="this.form.submit()">
                        <option value="">Semua Kelas</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $kelases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kelas->id); ?>" <?php echo e(request('kelas') == $kelas->id ? 'selected' : ''); ?>><?php echo e($kelas->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </select>
                </div>
                <div class="col-6 col-md-2">
                    <select name="gender" class="form-select" onchange="this.form.submit()">
                        <option value="">Semua Gender</option>
                        <option value="L" <?php echo e(request('gender') == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                        <option value="P" <?php echo e(request('gender') == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                    </select>
                </div>
                <div class="col-6 col-md-2">
                    <select name="jenjang" class="form-select" onchange="this.form.submit()">
                        <option value="">Semua Jenjang</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $jenjangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenjang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jenjang); ?>" <?php echo e(request('jenjang') == $jenjang ? 'selected' : ''); ?>><?php echo e($jenjang); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </select>
                </div>
                <div class="col-6 col-md-2">
                    <select name="jurusan" class="form-select" onchange="this.form.submit()">
                        <option value="">Semua Jurusan</option>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jurusan); ?>" <?php echo e(request('jurusan') == $jurusan ? 'selected' : ''); ?>><?php echo e($jurusan); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </select>
                </div>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="bg-light">
                    <tr>
                        <th class="py-3 ps-4" style="border-top-left-radius: 10px;">Nama Siswa</th>
                        <th class="py-3">Status</th>
                        <th class="py-3">Update Terakhir</th>
                        <th class="py-3 text-center">Mood Terakhir</th>
                        <th class="py-3 pe-4 text-center" style="border-top-right-radius: 10px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $siswaData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="ps-4 fw-medium"><?php echo e($siswa['nama']); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($siswa['status_color']); ?> bg-opacity-10 text-<?php echo e($siswa['status_color']); ?> border border-<?php echo e($siswa['status_color']); ?> rounded-pill px-3">
                                    <?php echo e($siswa['status_label']); ?>

                                </span>
                            </td>
                            <td class="text-muted"><?php echo e($siswa['last_update']); ?></td>
                            <td class="text-center h4 mb-0" title="<?php echo e($siswa['mood_label']); ?>">
                                <?php echo e($siswa['mood_emoji']); ?>

                            </td>
                            <td class="text-center">
                                <a href="<?php echo e(route('guru.mood.detail', $siswa['id'])); ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3">
                                    <i class="bi bi-eye me-1"></i> Lihat Detail
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center py-5 text-muted">
                                <i class="bi bi-people display-4 d-block mb-3"></i>
                                Belum ada data siswa yang mengambil tes DASS-21.
                            </td>
                        </tr>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guru', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arvin/riset/laravel/resources/views/guru/mood/index.blade.php ENDPATH**/ ?>