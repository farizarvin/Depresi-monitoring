<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php
    $pageTitle = 'Dashboard';
    $pageSubtitle = 'Panel Administrasi';
?>

<?php $__env->startSection('content'); ?>
    
    <div 
    class="row justify-content-center g-4"
    x-data="{
        calendars : <?php echo e(Js::from($calendars)); ?>,
        vacations : <?php echo e(Js::from($vacations)); ?>, 
        vacation : {}, 
        current : 0, 
        index : 0,
        loading : true,
        isEditing : false,
        selectedDates : [],
        async initData() 
        {
            

            
        },
        async showEvents(date)
        {
            const container=Alpine.$data(document.querySelector(`[x-ref='events_container']`))

            const lists=await this.vacations.filter(e=>{
                const bulanMulai=e.bulan_mulai;
                const bulanAkhir=e.bulan_selesai;
                const now=date * bulanMulai;
                return e.tanggal_mulai <= date && e.tanggal_selesai >= date;
            })
            

            const day=String(date).padStart(2, '0')
            const month=String(new Date().getMonth()+1).padStart(2, '0')
            container.events=lists
            container.date=`${day}-${month}`
        },
        chooseDate(date)
        {
        
            if(!this.isEditing) return
            if(this.selectedDates.length >= 2)
            {
                this.selectedDates=[]
                this.selectedDates.push(date)
                return;
            }
            this.selectedDates.push(date)
        
            this.selectedDates.sort((a,b)=>a - b);
        },
        isChosen(date)
        {
            const start = this.selectedDates[0];
            const end = this.selectedDates[1] || start;
            const chosen=start <= date && end >= date;
            return chosen;
        }
    }"

    x-init="initData"
    x-ref="dates_container">
        <!-- Schedule Column -->
        <div class="col-12 col-md-4 col-xl-3 mb-4">
            <form action="<?php echo e(route('admin.jadwal-harian.update')); ?>" method="post">
            <?php echo csrf_field(); ?>
                <div 
                id="accordionExample" 
                class="accordion accordion-flush border" 
                x-data="{ 
                    data : <?php echo e(Js::from($schedules)); ?>, 
                    grade : 1,
                    schedule : [],
                    days : {
                        0 : 'Senin', 
                        1 : 'Selasa',
                        2 : 'Rabu', 
                        3 : 'Kamis', 
                        4 : 'Jumat',
                        5 : 'Sabtu',
                        6 : 'Minggu'
                    },
                    setSchedule() 
                    {
                        this.schedule=this.data[this.grade]
                        console.log(this.schedule);
                    },
                    async initData()
                    {
                        schedule=await this.data;
                        schedule=this.data[this.grade];
                        this.schedule=schedule;
                    }
                }"
                x-init="initData;$watch('grade', _=>setSchedule())"
                >
                    
                    <div class="accordion-item">
                        <h2 class="accordion-header bg-success bg-gradient">
                            <button class="accordion-button fs-5 fw-bold text-primary py-4" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                Jadwal Harian
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                            <div class="accordion-body">
                                Atur jadwal masuk dan pulang sekolah untuk setiap jenjang.
                            </div>
                        </div>
                        <hr class="m-0">
                        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 px-3 py-3">
                            <div class="d-flex align-items-center">
                                <input type="checkbox" class="form-check-input" id="selectAllWeek">
                                <label for="selectAllWeek" class="form-check-label ms-2 fw-medium cursor-pointer">Select All</label>
                            </div>
                            <div class="w-auto">
                                <select name="jenjang" class="form-select form-select-sm bg-light" x-model="grade" style="min-width: 120px;">
                                    <option value="">--Pilih Jenjang--</option>
                                    <template x-for="i in 3" :key="i">
                                        <option :value="i" :selected="i===parseInt(grade)" x-text="'Jenjang '+i"></option>
                                    </template>
                                </select>
                                <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'jenjang'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>

                    
                    <template x-if="schedule?.jadwal?.length > 0">
                        <template x-for="(day, key) in days" :key="day">
                            <div class="accordion-item" :id="'heading'+key">
                                <h2 class="accordion-header">
                                    <button class="accordion-button collapsed d-flex align-items-center" type="button" data-bs-toggle="collapse" :data-bs-target="'#collapse'+key" aria-expanded="true" :aria-controls="'collapse'+key">
                                        
                                        <input type="checkbox" class="form-check" :name="`hari_libur[${key}]`" :value="key" :checked="!schedule?.hari_libur.includes(parseInt(key))">
                                        <div type="button" class="fs-6 fw-medium ms-2 text-black-50"  x-text="day">
                                        
                                        </div>
                                    </button>
                                </h2>
                                <div  :id="'collapse'+key" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                                    <div class="accordion-body bg-light-subtle">
                                        <div class="row align-items-end justify-content-e px-2">
                                            <div class="col p-0">
                                                <label class="fw-medium mb-1 fs-6">
                                                    <small>Mulai</small>
                                                </label>
                                                <input type="time" :name="`jadwal[${key}][jam_mulai]`" id="" class="form-control rounded-end-0 border-end-0" :value="schedule?.jadwal[key]?.jam_mulai">
                                            </div>
                                            <div class="col p-0">
                                                <label class="fw-medium mb-1 fs-6">
                                                    <small>Akhir</small>
                                                </label>
                                                <input type="time" :name="`jadwal[${key}][jam_akhir]`" id="" class="form-control rounded-0 border-end-0" :value="schedule?.jadwal[key]?.jam_akhir">
                                            </div>
                                            <div class="w-auto p-0">
                                                <button type="submit" class="btn btn-pill btn-primary rounded-start-0">Save</button>
                                            </div>
                                        </div>
                                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'jadwal'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'jadwal'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </template>
                    </template>
                    
                </div>
            </form>
        </div>

        <!-- Calendar Column -->
        <div class="col-12 col-md-8 col-xl-6 mb-4">
            <div 
            class="card"
            >
                <form 
                action="" 
                method="post">
                    <?php echo csrf_field(); ?>
                    <div class="card-header py-0 no-after d-flex justify-content-between align-items-center bg-success bg-gradient bg-opacity-50">
                        <div class="py-4">
                            <h1 class="fs-5 m-0 d-block text-black-50">
                                <strong class="text-black-50"><?php echo e(now()->format('F')); ?></strong> - <span class="font-weight-normal text-black-50"><?php echo e(now()->year); ?></span>
                            </h1>
                        </div>
                        
                        <div class="form-group d-flex m-0">
                            <select 
                            id="" 
                            name="" 
                            class="form-select bg-secondary-subtle fw-medium opacity-75">
                                <option value="">Januari</option>
                            </select>

                            <button
                            type="button"
                            x-on:click="isEditing=!isEditing;"
                            class="btn btn-warning btn-sm"
                            >
                                <i class="fas fa-edit"></i>
                            </button>
                        </div>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" style="table-layout: fixed;">
                                <thead class="bg-light">
                                    <?php
                                        $headers=['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
                                    ?>

                                    <tr>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <th 
                                            class="col text-center <?php echo e(in_array($key, [5, 6]) ? 'text-secondary' : ''); ?>"><?php echo e($header); ?></th>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                   
                                        
                                    <template x-for="week in calendars" :key="index">
                                        <tr>
                                            <template x-for="i in week[0].day">
                                                <td class="col p-0 bg-light">
                                                    
                                                </td>
                                            </template>
                                        
                                            <template x-for="day in week" :key="index+250">
                                                <td class="col p-0" style="box-sizing: border-box;">
                                                    <template x-if="([5,6]).includes(day.day)">
                                                        <button 
                                                        type="button"
                                                        class="w-100 h-100  px-0 rounded-0 border-0  position-relative btn btn-outline-light text-muted" disabled
                                                        x-data="{
                                                            vacant : false,
                                                            setLibur() {
                                                                current=day.date;   
                                                                this.vacant=vacations.some(vacation=>{
                                                                    return (vacation.tanggal_mulai <= current && current <= vacation.tanggal_selesai);
                                                                })
                                                            }
                                                        }"
                                                        x-init="setLibur()"
                                                        >
                                                            <div :class="{'bg-warning-subtle' : vacant}" x-text="day.date">
                                                                
                                                            </div>
                                                        </button>
                                                    </template>

                                                    <template x-if="!([5,6]).includes(day.day)">
                                                        <button 
                                                        
                                                        type="button"
                                                        class="w-100 h-100  px-0 rounded-0 border-0  position-relative text-body" 
                                                        
                                                        x-data="{
                                                            vacant : false,
                                                            setLibur() {
                                                                current=day.date    
                                                                this.vacant=vacations.some(vacation=>{
                                                                    return (vacation.tanggal_mulai <= current && current <= vacation.tanggal_selesai);
                                                                })
                                                            },
                                                            handleClick() {
                                                                if(isEditing) chooseDate(day.date);
                                                                else showEvents(day.date)
                                                            }
                                                        }"
                                                        :class="isChosen(day.date) ? 'btn bg-light' : 'btn btn-outline-light'"
                                                        x-on:click='handleClick'

                                                        x-init="setLibur()">
                                                            
                                                            <div :class="{'bg-warning-subtle' : vacant}" x-text="day.date">
                                                                
                                                            </div>
                                                        </button>
                                                    </template>
                                                    
                                                </td>
                                            </template>

                                            <template x-for="_ in 6 - (week[week.length-1]['day'] || 0)">
                                                <td class="col p-0 bg-light"></td>
                                            </template>
                                        </tr>
                                    </template>
                                
                                    
                                    <?php
                                        $current=0;
                                        $index=0;
                                    ?>
                                </tbody>
                            </table>
                            <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'id'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'date'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                        </div>
                        </ul>
                        
                    </div>
                </form>
            </div>

            <ul class="list-unstyled mt-3" x-data="{events : [], index : 0, date : ''}" x-ref="events_container">
                <template x-for="item in events" :key="index++">
                    <li class="list-item mb-2">
                        <div class="card bg-warning-subtle text-sm">
                            <div class="card-body no-after d-flex justify-content-between align-items-center">
                                <p class="m-0 font-weight-semibold text-black-50" style="font-size: 14px;" x-text="item.ket"></p>
                                <form action="<?php echo e(route('admin.presensi-libur.destroy')); ?>" method="post">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" x-model="item.id">
                                    <input type="hidden" name="date" x-model="date">
                                    <button type="submit" class="text-black-50 btn"><i class="fas fa-times"></i></button>
                                </form>
                            </div>
                        </div>
                    </li>
                </template>
            </ul>
            
        </div>

        <!-- Application / Info Column -->
        <div class="col-12 col-md-12 col-xl-3 mb-4">
            <form action="<?php echo e(route('admin.presensi-libur.store')); ?>" method="post" x-data="{
                async submitForm(event) {
                    const form = event.target;
                    const month = new Date().getMonth() + 1;
                    document.getElementById('tanggal_mulai').value= selectedDates[0]
                    document.getElementById('tanggal_selesai').value= selectedDates[1] || selectedDates[0]
                    document.getElementById('bulan_mulai').value= month
                    document.getElementById('bulan_selesai').value= month


                    form.submit();
                }
            }"
            @submit.prevent="submitForm">
                <?php echo csrf_field(); ?>
                <div class="card shadow-sm mb-4">
                    <div class="card-header py-4 bg-warning bg-gradient bg-opacity-50">
                        <h2 class="fs-5 fw-medium m-0 text-black-50">Add Event</h2>
                    </div>
                    <div class="card-body">
                        <input type="hidden" name="tanggal_mulai" id="tanggal_mulai">
                        <input type="hidden" name="tanggal_selesai" id="tanggal_selesai">
                        <input type="hidden" name="bulan_mulai" id="bulan_mulai">
                        <input type="hidden" name="bulan_selesai" id="bulan_selesai">
                        
                        <div class="mb-3">
                            <label for="ket_event" class="form-label fw-medium"><small>Keterangan Event</small></label>
                            <textarea  id="ket_event" cols="30" rows="5" class="form-control" name="ket" placeholder="Deskripsi event..."></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-medium d-block"><small>Jenjang</small></label>
                            <div class="d-flex gap-3">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="jenjang1" name="jenjang[]" value="1">
                                    <label class="form-check-label" for="jenjang1">1</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="jenjang2" name="jenjang[]" value="2">
                                    <label class="form-check-label" for="jenjang2">2</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="jenjang3" name="jenjang[]" value="3">
                                    <label class="form-check-label" for="jenjang3">3</label>
                                </div>
                            </div>
                        </div>

                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'jenjang'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'tanggal_mulai'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'tanggal_selesai'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'bulan_mulai'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'bulan_selesai'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalcae428af623b07e1f547152194a621f2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcae428af623b07e1f547152194a621f2 = $attributes; } ?>
<?php $component = App\View\Components\FormErrorText::resolve(['field' => 'ket'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FormErrorText::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $attributes = $__attributesOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__attributesOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcae428af623b07e1f547152194a621f2)): ?>
<?php $component = $__componentOriginalcae428af623b07e1f547152194a621f2; ?>
<?php unset($__componentOriginalcae428af623b07e1f547152194a621f2); ?>
<?php endif; ?>

                        <button type="submit" class="btn btn-primary w-100">Tambah</button>
                    </div>
                </div>
            </form>

            <form action="<?php echo e(route('admin.config.diary.update')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="card shadow-sm">
                    <div class="card-header py-4 bg-info bg-gradient bg-opacity-50">
                        <h2 class="fs-5 fw-medium m-0 text-black-50">Rekap Range</h2>
                    </div>
                    <div class="card-body">
                        <label for="rentang_field" class="form-label fw-medium">
                            <small>Rentang Hari</small>
                        </label>
                        <div class="input-group">
                            <input type="number" id="rentang_field" name="rentang" value="<?php echo e((int) ($diaryConfig['rentang'] ?? 7)); ?>" class="form-control">
                            <div class="input-group-text fs-6">
                                <small>days</small>
                            </div>
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </div>
                </div>
            </form>
            
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/arvin/riset/laravel/resources/views/dashboard/admin.blade.php ENDPATH**/ ?>