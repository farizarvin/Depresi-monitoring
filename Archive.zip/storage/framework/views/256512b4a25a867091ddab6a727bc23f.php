<a href="<?php echo e($href); ?>" class="nav-link <?php echo e($active ? 'active' : ''); ?>">
    <i class="bi <?php echo e($icon); ?> nav-icon"></i>
    <span class="nav-text"><?php echo e($text); ?></span>
</a>
<?php /**PATH /Users/arvin/riset/laravel/resources/views/components/buttons/button-sidebar.blade.php ENDPATH**/ ?>