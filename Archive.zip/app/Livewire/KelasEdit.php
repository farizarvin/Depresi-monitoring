<?php

namespace App\Livewire;

use Livewire\Component;

class KelasEdit extends Component
{
    public function render()
    {
        return view('livewire.kelas-edit');
    }
}
