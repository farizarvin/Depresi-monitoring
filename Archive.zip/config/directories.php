<?php

return 
[
    'user'=>
    [
        'url'=>'data/images/users/',
        'default_file'=>'no-profile.png'
    ]
];