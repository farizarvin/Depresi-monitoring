<?php
// File trigger di public_html
header("Location: https://penelitianku.my.id/dailyku/public/");
exit;
?>